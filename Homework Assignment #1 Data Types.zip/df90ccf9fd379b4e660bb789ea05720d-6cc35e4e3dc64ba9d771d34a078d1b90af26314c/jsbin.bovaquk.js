/* Bob Marley was born on 6 February, 1945, in Jamaica.
started his career with the Wailers, a group 
he formed with Peter Tosh and Bunny Livingston 
in 1963.Marley died on 11 May 1981 at Cedars of 
Lebanon Hospital in Miami */

//One love
var artist = "Bob Marley";
var genre = "Regae";
var song = "One Love";
var yearReleased = 1977;
var durationInSeconds = 165;
var homeTown = "Jamaica";

console.log(artist, genre, song, yearReleased, homeTown);



//Buffalo Soldier
var artist = "Bob Marley";
var genre = "Reggae";
var song = "Buffalo Soldier";
var yearReleased = 1978;
var durationInSeconds = 256;
var homeTown = "Jamaica";

console.log(artist, genre, song, yearReleased, homeTown);


//War
var artist = "Bob Marley";
var genre = "Reggae";
var Song = "war";
var yearReleased = 1976;
var durationInSeconds = 452;
var homeTown = "Jamaica";

console.log(artist, genre, song, yearReleased, homeTown);


//Stir it up
var artist = "Bob Marley";
var genre = "Regae";
var song = "Stir it up";
var yearReleased = 1977;
var durationInSeconds = 332;
var homeTown = "Jamaica";

console.log(artist, genre, song, yearReleased, homeTown);


//Get up, stand up
var artist = "Bob Marley";
var genre = "Regae";
var song = "Get up, stand up";
var yearReleased = 1977;
var durationInSeconds = 442;
var homeTown = "Jamaica";

console.log(artist, genre, song, yearReleased, homeTown);


//Booleans
var thatIsTrue = true;
var thatIsNull = null;

if (thatIsTrue = true) {
  console.log("Bob Marley was born on 6 February 1945");
} 
else {
  console.log("died on 11 May 1981 at Cedars of Lebanon Hospital in Miami");
}

var bobMarley = {
  Age: 46,
  Town: "Kingstone",
  Genre: "Reggae",
  Contry: "Jamirca",
  Dead: 1981,
};
console.log(bobMarley);